-- CREATE DATABASE FarewellParty;
-- Tashfeen Abbasi
-- abbasitashfeen7@gmail.com
USE FarewellParty;

CREATE TABLE Users (
    UserID INT AUTO_INCREMENT PRIMARY KEY,
    Username VARCHAR(50),
    Password VARCHAR(50) NOT NULL,
    Role ENUM('Student', 'Teacher', 'Organizer') NOT NULL
);

CREATE TABLE Students (
    StudentID INT AUTO_INCREMENT PRIMARY KEY,
    UserID INT,
    Name VARCHAR(100) NOT NULL,
    Email VARCHAR(100) NOT NULL,
    DietaryPreferences TEXT,
    AdditionalFamilyMembers INT DEFAULT 0,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

CREATE TABLE Teachers (
    TeacherID INT AUTO_INCREMENT PRIMARY KEY,
    UserID INT,
    Name VARCHAR(100) NOT NULL,
    Email VARCHAR(100) NOT NULL,
    AccompanyingFamilyMembers INT DEFAULT 0,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

CREATE TABLE FamilyMembers (
    FamilyMemberID INT AUTO_INCREMENT PRIMARY KEY,
    StudentID INT,
    Name VARCHAR(100) NOT NULL,
    Relationship VARCHAR(50) NOT NULL,
    FOREIGN KEY (StudentID) REFERENCES Students(StudentID)
);

CREATE TABLE MenuItems (
    MenuItemID INT AUTO_INCREMENT PRIMARY KEY,
    ItemName VARCHAR(100) NOT NULL,
    Votes INT DEFAULT 0
);

CREATE TABLE PerformanceProposals (
    ProposalID INT AUTO_INCREMENT PRIMARY KEY,
    PerformanceType VARCHAR(100) NOT NULL,
    Duration TIME NOT NULL,
    SpecialRequirements TEXT,
    Votes INT DEFAULT 0
);

CREATE TABLE Tasks (
    TaskID INT AUTO_INCREMENT PRIMARY KEY,
    Description TEXT NOT NULL,
    AssignedTo INT,
    Status ENUM('Pending', 'In Progress', 'Completed') DEFAULT 'Pending',
    FOREIGN KEY (AssignedTo) REFERENCES Users(UserID)
);

CREATE TABLE Attendance (
    AttendanceID INT AUTO_INCREMENT PRIMARY KEY,
    UserID INT,
    Status ENUM('Attended', 'Not Attended') NOT NULL,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

CREATE TABLE Budgets (
    BudgetID INT AUTO_INCREMENT PRIMARY KEY,
    Category VARCHAR(100) NOT NULL,
    Amount DECIMAL(10,2) NOT NULL,
    SpentAmount DECIMAL(10,2) DEFAULT 0
);

CREATE TABLE DecorationThemes (
    ThemeID INT AUTO_INCREMENT PRIMARY KEY,
    ThemeName VARCHAR(100) NOT NULL,
    Votes INT DEFAULT 0
);

CREATE TABLE Notifications (
    NotificationID INT AUTO_INCREMENT PRIMARY KEY,
    Category VARCHAR(100) NOT NULL,
    Message TEXT NOT NULL,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE users DROP INDEX email_unique;
ALTER TABLE users
ADD CONSTRAINT email_unique UNIQUE
(Username);

select * from students;
DELETE FROM students WHERE StudentID > 0;



