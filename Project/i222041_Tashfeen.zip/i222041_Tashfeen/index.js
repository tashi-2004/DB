const express = require('express');
const mysql = require('mysql2');
const path = require('path');
const bodyParser = require('body-parser'); // Middleware to parse form data

const app = express();
const port = 8080;


app.use(express.static(path.join(__dirname,'public')))
// Middleware to parse form data
app.use(bodyParser.urlencoded({ extended: false }));
const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "123456",
    database: "farewellparty"
});

connection.connect(function(err) {
    if (err) throw err;
    console.log("Connected to MySQL database!");
});

//-------------------------------------------------------------------------------//

// Route for serving the signup page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'signup.html'));
});

// Route for handling signup form submission
app.post('/signup', (req, res) => {
    const { username, password, role } = req.body;

    // Check if any required field is missing
    if (!username || !password || !role) {
        return res.status(400).send("All fields are required.");
    }

    // Check if the user already exists
    const checkUserExistsSQL = "SELECT COUNT(*) AS count FROM Users WHERE Username = ?";
    connection.query(checkUserExistsSQL, [username], function(err, results) {
        if (err) {
            console.error("Error checking user existence:", err);
            return res.status(500).send("An error occurred while checking user existence.");
        }

        const count = results[0].count;
        if (count > 0) {
            return res.status(400).send("User already exists!");
        }

        // Insert the user into the database
        const insertUserSQL = "INSERT INTO Users (Username, Password, Role) VALUES (?, ?, ?)";
        connection.query(insertUserSQL, [username, password, role], function(err, results) {
            if (err) {
                console.error("Error inserting user:", err);
                return res.status(500).send("An error occurred while registering the user.");
            }

            console.log("User registered successfully!");
            res.redirect('/login');
        });
    });
});




//-------------------------------------------------------------------------------//


// Route for serving the login page
app.get('/login', (req, res) => {
    res.sendFile(__dirname + '/login.html');
});

// Route for handling login form submission
app.post('/login', (req, res) => {
    const username = req.body.username;
    const password = req.body.password;

    // Check if username and password match a user in the database
    const query = `SELECT * FROM users WHERE username = '${username}' AND password = '${password}'`;

    connection.query(query, (error, results, fields) => {
        if (error) throw error;
        
        // If a user with the provided username and password exists, redirect to a success page
        if (results.length > 0) {
            res.redirect('/index');
        } else {
            // If no matching user is found, redirect back to the login page with an error message
            res.redirect('/?error=1');
        }
    });
});

// Route for serving the success page
// app.get('/success', (req, res) => {
//     res.send('Login successful!');
// });

//-------------------------------------------------------------------------------//

//Serve the index.html file
app.get('/index', function(req, res) {
    res.sendFile(path.join(__dirname, 'index.html'));
});


//-------------------------------------------------------------------------------//

// Serve HTML file for teacher registration form
app.get('/teacher-registration', function(req, res) {
    res.sendFile(path.join(__dirname, 'teacher-registration.html'));
});

// Handle POST request for teacher registration form submission
app.post('/teacher-registration', function(req, res) {
    const { teacherName, teacherEmail, accompanyingFamilyMembers } = req.body;

    const checkTeacherExistsSQL = "SELECT COUNT(*) AS count FROM Teachers WHERE Email = ?";
    connection.query(checkTeacherExistsSQL, [teacherEmail], function(err, results) {
        if (err) throw err;
        const count = results[0].count;
        if (count > 0) {
            res.status(400).send("Teacher already exists!");
        } else {
            const insertTeacherSQL = "INSERT INTO Teachers (Name, Email, AccompanyingFamilyMembers) VALUES (?, ?, ?)";
            connection.query(insertTeacherSQL, [teacherName, teacherEmail, accompanyingFamilyMembers], function(err, results) {
                if (err) throw err;
                console.log("Teacher registered successfully!");
                res.redirect('/teacher-registration');
            });
        }
    });
});

//-------------------------------------------------------------------------------//

// Serve HTML file for student registration form
app.get('/student-registration', function(req, res) {
    res.sendFile(path.join(__dirname, 'student-registration.html'));
});

// Handle POST request for student registration form submission
app.post('/student-registration', function(req, res) {
    const { studentName, studentEmail, dietaryPreferences, AdditionalFamilyMembers} = req.body;

    // Check if the student already exists
    const checkStudentExistsSQL = "SELECT COUNT(*) AS count FROM Students WHERE Email = ?";
    connection.query(checkStudentExistsSQL, [studentEmail], function(err, results) {
        if (err) throw err;
        const count = results[0].count;
        if (count > 0) {
            res.status(400).send("Student already exists!");
        } else {
            // Insert student information into Students table
            const insertStudentSQL = "INSERT INTO Students (Name, Email, DietaryPreferences,AdditionalFamilyMembers) VALUES (?, ?, ?,?)";
            connection.query(insertStudentSQL, [studentName, studentEmail, dietaryPreferences,AdditionalFamilyMembers], function(err, results) {
                if (err) throw err;
                console.log("Student registered successfully!");
                res.redirect('/student-registration');
            });
        }
    });
});

//-------------------------------------------------------------------------------//

// Serve HTML file for menu suggestions form
app.get('/menu', function(req, res) {
    res.sendFile(path.join(__dirname, 'menu.html'));
});

// Define a global variable to store user suggestions
const userSuggestions = {};
// Handle POST request for menu suggestions form submission
app.post('/menu', function(req, res) {
    const { menuItem, category } = req.body;

    // Check if the user has already suggested an item in this category
    if (userSuggestions[category]) {
        res.status(400).send("You have already suggested an item in this category!");
    } else {
        // If not, add the item to user suggestions and insert it into the database
        userSuggestions[category] = menuItem;

        // Check if the item already exists in the database
        const checkMenuItemExistsSQL = "SELECT COUNT(*) AS count FROM MenuItems WHERE ItemName = ?";
        connection.query(checkMenuItemExistsSQL, [menuItem], function(err, results) {
            if (err) throw err;
            const count = results[0].count;
            if (count > 0) {
                // If item already exists, update the count
                const updateMenuItemSQL = "UPDATE MenuItems SET Votes = Votes + 1 WHERE ItemName = ?";
                connection.query(updateMenuItemSQL, [menuItem], function(err, results) {
                    if (err) throw err;
                    console.log("Menu item count increased successfully!");
                    res.redirect('/menu');
                });
            } else {
                // If item does not exist, insert it into the database
                const insertMenuItemSQL = "INSERT INTO MenuItems (ItemName, Votes) VALUES (?, 1)";
                connection.query(insertMenuItemSQL, [menuItem, category], function(err, results) {
                    if (err) throw err;
                    console.log("Menu item suggested successfully!");
                    res.redirect('/menu');
                });
            }
        });
    }
});


//-------------------------------------------------------------------------------//

// Serve HTML file for performance proposal form
app.get('/performance', function(req, res) {
    res.sendFile(path.join(__dirname, 'performance.html'));
});

// Handle POST request for submitting performance proposals
app.post('/performance', function(req, res) {
    const { performanceType, duration, specialRequirements } = req.body;

    // Insert the submitted data into the PerformanceProposals table
    const insertProposalSQL = "INSERT INTO PerformanceProposals (PerformanceType, Duration, SpecialRequirements) VALUES (?, ?, ?)";
    connection.query(insertProposalSQL, [performanceType, duration, specialRequirements], function(err, results) {
        if (err) {
            console.error("Error inserting proposal:", err);
            res.status(500).send("An error occurred while processing your proposal.");
        } else {
            console.log("Proposal submitted successfully!");
            res.redirect('/performance'); // Redirect the user back to the performance proposal form
        }
    });
});

// Handle POST request for voting on performance proposals
// app.post('/performance', function(req, res) {
//     const { proposalID } = req.body;

//     // Increment the vote count for the specified proposal
//     const incrementVoteSQL = "UPDATE PerformanceProposals SET Votes = Votes + 1 WHERE PerformanceType = ?";
//     connection.query(incrementVoteSQL, [proposalID], function(err, results) {
//         if (err) {
//             console.error("Error incrementing vote count:", err);
//             res.status(500).send("An error occurred while processing your vote.");
//         } else {
//             console.log("Vote counted successfully!");
//             res.redirect('/performance'); // Redirect the user back to the performance proposal form
//         }
//     });
// });

// Serve performance proposals
// app.post('/performance', function(req, res) {
//     const getProposalsSQL = "SELECT * FROM performanceproposals";
//     connection.query(getProposalsSQL, function(err, results) {
//         if (err) {
//             console.error("Error fetching proposals:", err);
//             res.status(500).send("An error occurred while fetching proposals.");
//         } else {
//             res.json(results);
//         }
//     });
// });


//-------------------------------------------------------------------------------//
// Serve HTML file for budget tracking form
app.get('/budget', function(req, res) {
    res.sendFile(path.join(__dirname, 'budget_tracking.html'));
});

// Handle POST request for budget tracking form submission
app.post('/budget', function(req, res) {
    const { category, amount, spentAmount } = req.body;

    // Insert budget tracking data into the Budgets table
    const insertBudgetSQL = "INSERT INTO Budgets (Category, Amount, SpentAmount) VALUES (?, ?, ?)";
    connection.query(insertBudgetSQL, [category, amount, spentAmount], function(err, results) {
        if (err) {
            console.error("Error inserting budget data:", err);
            res.status(500).send("An error occurred while processing your budget data.");
        } else {
            console.log("Budget data inserted successfully!");
            res.redirect('/budget'); // Redirect the user back to the budget tracking form
        }
    });
});

// // Define the SQL code to create the trigger
// const addBudgetTrigger = `
//     CREATE TRIGGER update_budget_status AFTER INSERT ON Budgets
//     FOR EACH ROW
//     BEGIN
//         DECLARE remaining DECIMAL(10,2);
//         SET remaining = NEW.Amount - NEW.SpentAmount;
//         UPDATE Budgets SET SpentAmount = NEW.SpentAmount WHERE Category = NEW.Category;
//         UPDATE Budgets SET RemainingAmount = remaining WHERE Category = NEW.Category;
//     END
// `;

// // Check if the trigger already exists
// connection.query("SHOW TRIGGERS LIKE 'update_budget_status'", function(err, results) {
//     if (err) {
//         console.error("Error checking trigger:", err);
//     } else {
//         if (results.length > 0) {
//             console.log("Trigger already exists, skipping creation.");
//         } else {
//             // Trigger doesn't exist, create it
//             connection.query(addBudgetTrigger, function(err, results) {
//                 if (err) {
//                     console.error("Error creating trigger:", err);
//                 } else {
//                     console.log("Trigger created successfully!");
//                 }
//             });
//         }
//     }
// });



// // Add the stored procedure for checking budget thresholds
// const addBudgetThresholdProcedure = `
// CREATE PROCEDURE check_budget_threshold()
// BEGIN
//     DECLARE done INT DEFAULT FALSE;

//     DECLARE budget_id INT;
//     DECLARE category_name VARCHAR(100);
//     DECLARE budget_amount DECIMAL(10,2);
//     DECLARE spent_amount DECIMAL(10,2);
//     DECLARE remaining_amount DECIMAL(10,2);
//     DECLARE threshold DECIMAL(10,2);

//     -- Cursor to loop through budget records
//     DECLARE budget_cursor CURSOR FOR
//         SELECT BudgetID, Category, Amount, SpentAmount
//         FROM Budgets;

//     -- Declare continue handler for the cursor
//     DECLARE CONTINUE HANDLER FOR NOT FOUND
//         SET done = TRUE;

//     OPEN budget_cursor;
//     budget_loop: LOOP
//         FETCH budget_cursor INTO budget_id, category_name, budget_amount, spent_amount;
//         IF done THEN
//             LEAVE budget_loop;
//         END IF;

//         SET remaining_amount = budget_amount - spent_amount;
//         SET threshold = budget_amount * 0.8; -- 80% threshold

//         IF spent_amount >= threshold THEN
//             -- Implement your notification mechanism here
//             INSERT INTO Notifications (Category, Message) VALUES (category_name, CONCAT('Budget threshold exceeded for ', category_name));
//         END IF;
//     END LOOP;

//     CLOSE budget_cursor;
// END
// `;

// // Drop the existing stored procedure if it exists
// connection.query("DROP PROCEDURE IF EXISTS check_budget_threshold", function(err, results) {
//     if (err) {
//         console.error("Error dropping procedure:", err);
//     } else {
//         console.log("Procedure dropped successfully!");
//         // Now you can add the stored procedure again
//         connection.query(addBudgetThresholdProcedure, function(err, results) {
//             if (err) {
//                 console.error("Error adding stored procedure:", err);
//             } else {
//                 console.log("Stored procedure added successfully!");
//             }
//         });
//     }
// });

//-------------------------------------------------------------------------------//

// // Serve the reports to teachers
// app.get('teachers', function(req, res) {
//     const query = 'SELECT * FROM Teachers';
//     connection.query(query, function(err, results) {
//         if (err) throw err;
//         res.json(results);
//     });
// });

// // Serve the reports to students
// app.get('/reports/students', function(req, res) {
//     const query = 'SELECT s.Name AS StudentName, s.Email AS StudentEmail, s.DietaryPreferences, f.Name AS FamilyMemberName, f.Relationship FROM Students s LEFT JOIN FamilyMembers f ON s.StudentID = f.StudentID';
//     connection.query(query, function(err, results) {
//         if (err) throw err;
//         res.json(results);
//     });
// });

// // Serve the reports to organizers
// app.get('/reports/organizers', function(req, res) {
//     const queries = [
//         'SELECT * FROM Budgets',
//         'SELECT * FROM MenuItems',
//         'SELECT * FROM PerformanceProposals',
//         'SELECT * FROM Notifications'
//     ];

//     const reports = {};

//     // Execute multiple queries in parallel
//     connection.query(queries.join(';'), function(err, results) {
//         if (err) throw err;

//         reports.budgets = results[0];
//         reports.menuItems = results[1];
//         reports.performanceProposals = results[2];
//         reports.notifications = results[3];

//         res.json(reports);
//     });
// });

//-------------------------------------------------------------------------------//

// Start the server
app.listen(port, function() {
    console.log(`Server is running on port ${port}`);
});
