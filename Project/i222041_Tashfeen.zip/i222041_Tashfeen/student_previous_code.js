// Handle POST request for student registration form submission
app.post('/student-registration', function(req, res) {
    const { studentName, studentEmail, dietaryPreferences, additionalFamilyMembers } = req.body;

    // Check if the student already exists
    const checkStudentExistsSQL = "SELECT COUNT(*) AS count FROM Students WHERE Email = ?";
    connection.query(checkStudentExistsSQL, [studentEmail], function(err, results) {
        if (err) throw err;
        const count = results[0].count;
        if (count > 0) {
            res.status(400).send("Student already exists!");
        } else {
            // Insert student information into Students table
            const insertStudentSQL = "INSERT INTO Students (Name, Email, DietaryPreferences) VALUES (?, ?, ?)";
            connection.query(insertStudentSQL, [studentName, studentEmail, dietaryPreferences], function(err, results) {
                if (err) throw err;
                console.log("Student registered successfully!");
                res.redirect('/student-registration');
            });
        }
    });
});
